package io.braintop.myshare;


import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class ProductOpenHelper extends SQLiteOpenHelper {
    public static final String DATABASENAME="product.db";
    public static final String TABLE_PRODUCT="tblproducts";
    public static final int DATABASEVERSION=1;

    public static final String COLUMN_ID="productId";
    public static final String COLUMN_NAME="name";
    public static final String COLUMN_DESCRIPTION="description";
    public static final String COLUMN_PRICE="price";

    SQLiteDatabase database;


    public ProductOpenHelper(Context context) {
            super(context, DATABASENAME, null, 1);
            // TODO Auto-generated constructor stub
        }
    private static final String CREATE_TABLE_PPRODUCT="CREATE TABLE IF NOT EXISTS " +
            TABLE_PRODUCT + "(" + COLUMN_ID +  " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_NAME + " VARCHAR," + COLUMN_DESCRIPTION + " VARCHAR,"
            + COLUMN_PRICE +   " INTEGER "  +   ");";


    String []allColumns={ProductOpenHelper.COLUMN_ID, ProductOpenHelper.COLUMN_NAME,ProductOpenHelper.COLUMN_DESCRIPTION,
            ProductOpenHelper.COLUMN_PRICE};


    @Override
    public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREATE_TABLE_PPRODUCT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void open(){
            database=this.getWritableDatabase();
            Log.d("data", "Database connection open");

    }
    //quearies ......
    public Product createProduct(Product p)
    {
        ContentValues values=new ContentValues();
        values.put(ProductOpenHelper.COLUMN_NAME, p.getName());
        values.put(ProductOpenHelper.COLUMN_DESCRIPTION, p.getDescription());
        values.put(ProductOpenHelper.COLUMN_PRICE, p.getPrice());

        long insertId=database.insert(ProductOpenHelper.TABLE_PRODUCT, null, values);
        Log.i("data", "Product " + insertId + "insert to database");
        p.setProductId(insertId);
        return p;
    }

}
