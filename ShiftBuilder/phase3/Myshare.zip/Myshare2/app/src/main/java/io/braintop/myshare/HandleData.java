package io.braintop.myshare;

public class HandleData {
}
