package io.braintop.myshare;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    final String FIRSTNAME = "firstname";
    final String LASTNAME = "lastname";

    //dialog
    Dialog dialog;
    Button btnDialogSave, btnDialogCansel;

    Button btnSave;
    EditText etFname,etLname;
    TextView tvDisplay;
    int x = 5 ; // int type , x key , 5 value
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSave=(Button)findViewById(R.id.btnSubmit);
        btnSave.setOnClickListener(this);
        etFname=(EditText)findViewById(R.id.etFname);
        etLname=(EditText)findViewById(R.id.etLname);
        tvDisplay=(TextView)findViewById(R.id.tvDisplay);
        sharedPreferences = getSharedPreferences("details1", 0);
        showData();
        createDialog();
    }
    public void createDialog(){
        dialog = new Dialog(this);

        dialog.setContentView(R.layout.custom);
        btnDialogSave = dialog.findViewById(R.id.btnSave);
        btnDialogCansel = dialog.findViewById(R.id.btnCancel);
        btnDialogCansel.setOnClickListener(this);
        btnDialogSave.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        if(btnSave==v){
            dialog.show();
        }
        else if(btnDialogSave==v){
            save();
            dialog.dismiss();//close dialog
            Toast.makeText(this,"Data saved",Toast.LENGTH_LONG).show();

        }
        else if(btnDialogCansel==v){
            dialog.dismiss();//dont save - close dialog
            Toast.makeText(this,"Data Cancel",Toast.LENGTH_LONG).show();

        }

    }
    public void save(){


        SharedPreferences.Editor  editor = sharedPreferences.edit();
        editor.putString(FIRSTNAME, etFname.getText().toString());
        editor.putString(LASTNAME, etLname.getText().toString());
        editor.commit();//save
    }

    public void showData(){
        String firstname = sharedPreferences.getString(FIRSTNAME,null);
        String lastname = sharedPreferences.getString(LASTNAME,null);

        if(firstname!=null){
            etFname.setText(firstname);
        }
        if(lastname!=null){
            etLname.setText(lastname);
        }


    }

    public void insert(){
        //    public Product(String name, String description, int price) {
        Product p = new Product("sasas","sasas",34);
        ProductOpenHelper prh = new ProductOpenHelper(this);
        prh.open();
        prh.createProduct(p);
        prh.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.action_login){
            Toast.makeText(this, "Login selected",Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }
        else if(item.getItemId()==R.id.action_register){
            Toast.makeText(this, "Register selected",Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, RegisterActivity.class);
            startActivity(intent);
        }
        return true;
    }
}
//1. dialog
//2. toast
//3. menu
//4. intent :  this => RegisterActivity